Laufprobe v9: vereinfachte Katze mit den 32 Schrittposen der früheren Version.

Walk-01.png bis Walk-32.png in dieser Reihenfolge abspielen, 32 Bilder pro Sekunde. Danach wieder bei Walk-01.png beginnen. Ein Durchlauf dauert 1 Sekunde. Alle Bilder: 1343 x 1024 Pixel, transparenter Hintergrund, gemeinsame Ausrichtung.

Originalebenen liegen unverändert im Unterordner Originale; die Namen Sit-1.png bis Sit-7.png bleiben erhalten.

Keine Änderung am Godot-Spielprojekt.
