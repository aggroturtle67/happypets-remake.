# Schwarze Katzensilhouette – eigenständige Laufprobe

Neue, prozedural gezeichnete Vektorkatze. Keine Bilddateien, Konturen, Körperteile oder Posen aus den bisherigen Nutzerdateien werden geladen oder übernommen. Das Rendering benötigt nur index.html.

48 Bilder pro Sekunde, ein Laufzyklus dauert eine Sekunde. Vier zeitlich versetzte Bodenkontakte; während der Stützphase bleibt die Pfotenhöhe konstant und die Pfotenbewegung entspricht einer gemeinsamen Vorwärtsgeschwindigkeit des Körpers. Die Vorschau zeigt den Zyklus auf der Stelle. Transparente PNG-Bilder enthalten nur schwarze Flächen und Kantenglättung.

index.html über HTTP auf Port 8087 bereitstellen und node render.mjs ausführen. Die Prüfungen erfassen Gelenklängen, Erreichbarkeit, konstante Stützbewegung, gleichmäßige Übergänge und die Schleife. Sie garantieren keine naturgetreue Animation. Das Spielprojekt wird nicht verändert.
