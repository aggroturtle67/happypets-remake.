Einzelbilder aus 4115671-preview.mp4

807 PNG-Bilder in der Originalreihenfolge: Frame-0001.png bis Frame-0807.png.
Originalauflösung: 596 x 336 Pixel.
Originalbildrate: 29,97 Bilder pro Sekunde.
Dauer: etwa 26,93 Sekunden.

Die Bilder sind vollständig und ohne Zuschnitt aus dem Video dekodiert. Hintergrund und Wasserzeichen bleiben erhalten. Es wurden keine Zwischenbilder ergänzt.

Zeitpunkte.csv ordnet jedem Bild seinen Zeitpunkt im Video zu.
