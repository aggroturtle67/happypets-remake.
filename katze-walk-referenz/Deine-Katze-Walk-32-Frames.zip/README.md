# Graue Katze – Walk-Frames nach Bewegungsreferenz

32 neue, transparente Walk-Bilder mit den vorhandenen vereinfachten Nutzer-Grafiken. Kopf, Körper, Schwanz und Pfotenausschnitte stammen aus Sit-1.png bis Sit-7.png. Die Originaldateien werden nicht verändert oder umbenannt. Die Beinprofile werden in jedem Bild neu gezeichnet, in demselben RGB-Grau 91/91/91 für alle vier Beine.

Die Referenz 4115671-preview.mp4 wurde zur Beobachtung der Schrittposen benutzt. Handangepasste Gelenkposen werden auf die anderen Proportionen der gezeichneten Katze übertragen. Das ist keine automatische Bewegungsaufnahme und keine pixelgenaue Nachzeichnung der Videokatze. Die frühere Silhouettenanimation wird nicht übernommen. Die Gehhaltung senkt den vorhandenen Kopf und komprimiert den Halsbereich der Körpergrafik; der Gesichtsausdruck und die Kopfzeichnung bleiben erhalten. Der Schwanz bewegt sich verzögert am Ansatz.

Bilder/Walk-01.png bis Walk-32.png, Reihenfolge aufsteigend, 32 Bilder pro Sekunde, 1 Sekunde pro Schleife. Gemeinsame Bildfläche 1472 x 1024 Pixel. Rechts wurde transparenter Platz ergänzt, damit ausgestreckte Pfoten nicht abgeschnitten werden. Originaler Zeichenmaßstab und Koordinatenursprung bleiben erhalten. Die Vorschau zeigt den Lauf auf der Stelle. Keine Änderung am Godot-Spielprojekt.

Zum Reproduzieren die Quelldateien auf Port 8089 per HTTP bereitstellen und node render.mjs ausführen. Die Prüfungen erfassen die Schleife, kontinuierliche Gelenkbewegungen, Stützpfoten, Gelenkreihenfolge und vollständig sichtbare, verbundene Figuren. Sie sind keine Garantie für realistische Tierbewegung.
